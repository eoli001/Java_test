:

java -classpath "dist/lib/*:lib/*" RecordMerger $*
