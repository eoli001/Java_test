import java.util.ArrayList;
import java.util.*;

public class Record {
	private int id;
	private ArrayList<String> otherCol;

	Record() {
		id = -1;
		otherCol = new ArrayList<String>();
	}

	Record(int id, ArrayList<String> otherCol) {
		this.id = id;
		this.otherCol = otherCol;
	}

	public int getid() {
		return id;
	}

	public ArrayList<String> getotherCol() {
		return otherCol;
	}

	public String getCol(int index) {
		return otherCol.get(index);
	}

	public int getotherColCount() {
		return otherCol.size();
	}

	public void setid(int id) {
		this.id = id;
	}

	public void setotherCol(ArrayList<String> otherCol) {
		this.otherCol = new ArrayList<String>(otherCol);
	}

	public void setCol(int index, String element) {
		otherCol.set(index, element);
	}

	public void addCol(String Col) {
		otherCol.add(Col);
	}
	
	public void printRecord(){
		System.out.printf("|");
		System.out.printf("%-15s", id);
		System.out.printf("|");
		
		for (String Col : otherCol){
			System.out.printf("%-15s", Col);
			System.out.printf("|");
		}
		
		String newLine = System.getProperty("line.separator");
	    System.out.println(newLine);
	}
	
	
}


