import java.io.IOException;
import java.io.Reader;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import au.com.bytecode.opencsv.CSVReader;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class RecordCSVParser extends RecordParser {

	public static RecordTable getCSVTable(Path input) {// i.e."./data/secnd.csv"

		RecordTable recordtable = new RecordTable();
		int idColNum = -1;
		CSVReader csvReader = null;
		String[] readNextLine;
		boolean isHeaderSet = false;

		if (!validPath(input)) {
			try {
				throw new Exception("Invalid path: " + input.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		try {
			//Parsing headers by using CSVReader
			csvReader = new CSVReader(new InputStreamReader(new FileInputStream(input.toString()), "UTF-8"));
			readNextLine = csvReader.readNext();

			while (!(readNextLine == null)) {
				if (!isHeaderSet) {
					for (int i = 0; i < readNextLine.length; i++) {
						//find the line contains ID
						if (readNextLine[i] == "ID") {

							idColNum = i;
							ArrayList<String> headers = new ArrayList<String>();

							for (int j = 0; j < readNextLine.length; j++) {
								if (j != i) {
									headers.add(readNextLine[j]);
								}
							}
							
							recordtable.setHeaders(headers);
							isHeaderSet = true;
							break;
						}
					}
					
				}
				//Parsing records
				else {
					Record r = new Record();
					for (int i = 0; i < readNextLine.length; i++) {
						if (i == idColNum) {
							r.setid(Integer.parseInt(readNextLine[i]));
						} else {
							r.addCol(readNextLine[i]);
						}
					}
					recordtable.addRecord(r);
				}
				
				readNextLine = csvReader.readNext();
			}
		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			try {
				csvReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return recordtable;

	}
}
