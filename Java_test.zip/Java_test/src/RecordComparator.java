import java.util.*;

class RecordComparator implements Comparator<Record> {
	@Override
	public int compare(Record r1, Record r2) {
		return r1.getid() - r2.getid();
	}
	
}	