import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import java.util.ArrayList;

public class RecordHtmlParser extends RecordParser {

	public static RecordTable getHtmlTable(Path input) {// "./data/first.html"
		RecordTable recordtable = new RecordTable();
		ArrayList<String> recordHeader = new ArrayList<String>();
		int idColNum = -1;

		if (!validPath(input)) {
			try {
				throw new Exception("Invalid path: " + input.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		File in = new File(input.toString());
		Document doc = null;
		try {
			doc = Jsoup.parse(in, "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Parsing header from HTML file
		Elements headerElements = doc.select("tr>th");
		Record record = new Record();

		for (int i = 0; i < headerElements.size(); i++) {
			String HeaderCol = headerElements.get(i).text();

			if (HeaderCol == "ID")
				idColNum = i;
			recordHeader.add(HeaderCol);
		}

		recordtable.setHeaders(recordHeader);

		// Parsing record from HTML table
		Elements tableElements = doc.select("tr>td");
		for (int i = 0; i < tableElements.size(); i++) {
			Elements tableitems = tableElements.get(i).select("td");

			if (tableitems.size() == 0)
				continue;

			for (int j = 0; j < tableitems.size(); j++) {
				String tablerecord = tableitems.get(j).text();
				if (j == idColNum) {
					record.setid(Integer.parseInt(tablerecord));
				} else {
					record.addCol(tablerecord);
				}
			}

		}
		try {
			recordtable.addRecord(record);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return recordtable;
	}
}
