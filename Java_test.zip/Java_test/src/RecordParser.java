import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class RecordParser {

	public static boolean validPath(Path input) {
		if (!Files.exists(input)) {
			return false;
		}

		return true;
	}
}
