import java.util.*;
import java.util.TreeMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;

public class RecordTable {
	private ArrayList<String> Headers;
	private ArrayList<Record> Records;

	public RecordTable() {
		Headers = new ArrayList<String>();
		Records = new ArrayList<Record>();
	}

	public ArrayList<String> getHeaders() {
		return Headers;
	}

	public ArrayList<Record> getRecords() {
		return Records;
	}

	public Record getRecordsByIndex(int index) {
		return Records.get(index);
	}

	public int getRecordsCount() {
		return Records.size();
	}

	public void setHeaders(ArrayList<String> headers) {
		this.Headers.addAll(headers);
	}

	public void addRecord(Record record) throws Exception {

		if (record.getotherColCount() != Headers.size()) {

			throw new Exception("Number of records count: " + record.getotherColCount()
					+ " which doesn't match the number of header count: " + Headers.size() + " in RecordTable");
		}
		if (record.getid() == -1) {

			throw new Exception("record ID is not valid: " + record.getid());
		}
		Records.add(record);
	}

	// sort
	public void sortTable() {
		Collections.sort(Records, new RecordComparator());
	}

	// Remove duplicate by using Treemap
	public void removeDulplicateRecord() {

		TreeMap<Integer, Record> recordMap = new TreeMap<Integer, Record>();
		for (Record record : Records) {
			recordMap.put(record.getid(), record);
		}
		Records.clear();
		for (int recordkey : recordMap.keySet()) {
			Records.add(recordMap.get(recordkey));
		}
	}

	// Print table
	public void printTable() {
		if (Records.size() == 0) {
			System.out.println("There is no record.");
		} else {
			// print header part
			System.out.printf("|");
			System.out.printf("%-15s", "ID");
			System.out.printf("|");

			for (String header : Headers) {
				System.out.printf("%-15s", header);
				System.out.printf("|");
			}

			String newLine = System.getProperty("line.separator");
			System.out.println(newLine);

			// print the rest of table
			for (Record r : Records) {
				r.printRecord();
			}
		}
	}
}
